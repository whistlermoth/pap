<form action="{{ route('import-excel') }}" method="post" enctype="multipart/form-data">
    @csrf
    <input type="file" name="file">
    <button type="submit">Import Excel</button>
</form>

Posisi Bulan Lalu<br>
NoC : {{ $record->sum('noc_bln_lalu') }}<br>
Outstanding : {{ $record->sum('os_bln_lalu') }}<br>
NoA PAR : {{ $record->sum('noa_par_bln_lalu') }}<br>
OS PAR : {{ $record->sum('os_par_bln_lalu') }}<br>
NoA NPL : {{ $record->sum('noa_npl_bln_lalu') }}<br>
OS NPL : {{ $record->sum('os_npl_bln_lalu') }}<br>
<hr>
Growth NoC : {{ strtr($record->sum('growth_noc_bln_lalu'), ['%' => '']) }}<br>
Growth OS : {{ strtr($record->sum('growth_os_bln_lalu'), ['%' => '']) }}<br>
Progress NoA PAR : {{ $record->sum('progres_noa_par_bln_lalu') }}<br>
Progress NoA PAR : {{ $record->sum('progres_os_par_bln_lalu') }}<br>

<br>
<br>
Posisi Aktual<br>
NoA : {{ $record->sum('noa') }}<br>
NoC : {{ $record->sum('noc') }}<br>
Target EoM : {{ $record->sum('target_eom_noc') }}<br>
% EoM : {{ $record->sum('noc') / $record->sum('target_eom_noc') * 100 }}<br>
Growth : {{ $record->sum('noc') - $record->sum('noc_bln_lalu') }}<br>
DO Bulan Ini : {{ $record->sum('do_bln_ini') }}<br>
Target EoY : {{ $record->sum('target_eoy_noc') }}<br>
% EoY : {{ $record->sum('noc') / $record->sum('target_eoy_noc') * 100 }}<br>
<hr>
OS : {{ $record->sum('os_actual') }}<br>
Target EoM : {{ $record->sum('target_eom_os') }}<br>
% EoM : {{ $record->sum('os_actual') / $record->sum('target_eom_os') * 100 }}<br>
Growth : {{ $record->sum('os_actual') - $record->sum('os_bln_lalu') }}<br>
Run Off (1 Minggu) : {{ $record->sum('runoff') }}<br>
Run Off (1 Bulan) : {{ $record->sum('runoff') * 4 }}<br>
Target EoY : {{ $record->sum('target_eoy_os') }}<br>
% EoY : {{ $record->sum('os_actual') / $record->sum('target_eoy_os') * 100 }}<br>
<hr>
DRTD (NoA) : {{ $record->sum('kewajiban_drtd_noa') }}<br>
DRTD (Rp) : {{ $record->sum('kewajiban_drtd_nominal') }}<br>
UK & PNC AO (Harian) : {{ $record->sum('uk_dan_pnc_ao') }}<br>


<br>
<br>
Quality Aktual<br>
NoA PAR : {{ $record->sum('noa_par') }}<br>
Progress : {{ $record->sum('noa_par') - $record->sum('noa_par_bln_lalu') }}<br>
% NoA PAR : {{ $record->sum('noa_par') / $record->sum('noa') * 100 }}<br>
<hr>
OS PAR : {{ $record->sum('os_par') }}<br>
Progress : {{ $record->sum('os_par') - $record->sum('os_par_bln_lalu') }}<br>
% OS PAR : {{ $record->sum('os_par') / $record->sum('os_actual') * 100 }}<br>
% RR : {{ $record->sum('percentage_rr') }}<br>
Target EoM : {{ $record->sum('target_eom_par') }}<br>
% EoM : {{ $record->sum('target_eom_par') / $record->sum('os_par')  * 100 }}<br>
<hr>
NoA NPL : {{ $record->sum('noa_npl') }}<br>
Progress : {{ $record->sum('noa_npl') - $record->sum('noa_npl_bln_lalu') }}<br>
% NoA NPL : {{ $record->sum('noa_npl') / $record->sum('noa') * 100 }}<br>
<hr>
OS NPL : {{ $record->sum('os_npl') }}<br>
Progress : {{ $record->sum('os_npl') - $record->sum('os_npl_bln_lalu') }}<br>
% OS NPL : {{ $record->sum('os_npl') / $record->sum('os_actual') * 100 }}<br>
Target EoM : {{ $record->sum('target_eom_npl') }}<br>
% EoM : {{ $record->sum('target_eom_npl') / $record->sum('os_npl')  * 100 }}<br>
<hr>
PKM : {{ $record->sum('pkm') }}<br>
Anggota > 30 : {{ $record->sum('pkm_gt_30')}}<br>
Anggota < 10 : {{ $record->sum('pkm_lt_10')}}<br>

<br>
<br>
SDM
AO : {{ $record->sum('jumlah_ao') }}<br>
FAO : {{ $record->sum('fao') }}<br>
SAO : {{ $record->sum('sao') }}<br>
KUM : {{ $record->sum('kum') }}<br>
Keb. AO : {{ $record->sum('kebutuhan_ao') }}<br>
Keb. FAO : {{ $record->sum('kebutuhan_fao') }}<br>
Keb. SAO : {{ $record->sum('kebutuhan_sao') }}<br>
Keb. KUM : {{ $record->sum('kebutuhan_kum') }}<br>
{{-- % EoM : {{ $record->sum('noc') / $record->sum('target_eom_noc') * 100 }}<br>
Growth : {{ $record->sum('noc') - $record->sum('noc_bln_lalu') }}<br>
DO Bulan Ini : {{ $record->sum('do_bln_ini') }}<br>
Target EoY : {{ $record->sum('target_eoy_noc') }}<br>
% EoY : {{ $record->sum('noc') / $record->sum('target_eoy_noc') * 100 }}<br>
<hr>
OS : {{ $record->sum('os_actual') }}<br>
Target EoM : {{ $record->sum('target_eom_os') }}<br>
% EoM : {{ $record->sum('os_actual') / $record->sum('target_eom_os') * 100 }}<br>
Growth : {{ $record->sum('os_actual') - $record->sum('os_bln_lalu') }}<br>
Run Off (1 Minggu) : {{ $record->sum('runoff') }}<br>
Run Off (1 Bulan) : {{ $record->sum('runoff') * 4 }}<br>
Target EoY : {{ $record->sum('target_eoy_os') }}<br>
% EoY : {{ $record->sum('os_actual') / $record->sum('target_eoy_os') * 100 }}<br>
<hr>
DRTD (NoA) : {{ $record->sum('kewajiban_drtd_noa') }}<br>
DRTD (Rp) : {{ $record->sum('kewajiban_drtd_nominal') }}<br>
UK & PNC AO (Harian) : {{ $record->sum('uk_dan_pnc_ao') }}<br> --}}
