<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Imports\ImportExcelMekaar;
use App\Models\Mekaar;
use Maatwebsite\Excel\Facades\Excel;

class MekaarController extends Controller
{
    public function importExcel(Request $request)
    {
        $request->validate([
            'file' => 'required|mimes:xls,xlsx',
        ]);

        $file = $request->file('file');

        Excel::import(new ImportExcelMekaar, $file);

        return redirect()->back()->with('success', 'Excel data imported successfully');
    }

    public function index(Request $request){
        if(!empty($request->area)){
            $record = Mekaar::where('area', $request->area)->get();
        }elseif(!empty($request->region)){
            $record = Mekaar::where('region', $request->region)->get();
        }elseif(!empty($request->unit)){
            $record = Mekaar::where('cabang', $request->unit)->get();
        }else{
            $record = Mekaar::where('id', 93)->get();
            $record = null;
        }
        return view('index', compact('record'));
    }
}
