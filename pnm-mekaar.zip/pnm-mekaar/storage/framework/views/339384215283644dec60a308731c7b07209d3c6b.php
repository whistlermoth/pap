<form action="<?php echo e(route('import-excel')); ?>" method="post" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <input type="file" name="file">
    <button type="submit">Import Excel</button>
</form>

Posisi Bulan Lalu<br>
NoC : <?php echo e($record->sum('noc_bln_lalu')); ?><br>
Outstanding : <?php echo e($record->sum('os_bln_lalu')); ?><br>
NoA PAR : <?php echo e($record->sum('noa_par_bln_lalu')); ?><br>
OS PAR : <?php echo e($record->sum('os_par_bln_lalu')); ?><br>
NoA NPL : <?php echo e($record->sum('noa_npl_bln_lalu')); ?><br>
OS NPL : <?php echo e($record->sum('os_npl_bln_lalu')); ?><br>
<hr>
Growth NoC : <?php echo e(strtr($record->sum('growth_noc_bln_lalu'), ['%' => ''])); ?><br>
Growth OS : <?php echo e(strtr($record->sum('growth_os_bln_lalu'), ['%' => ''])); ?><br>
Progress NoA PAR : <?php echo e($record->sum('progres_noa_par_bln_lalu')); ?><br>
Progress NoA PAR : <?php echo e($record->sum('progres_os_par_bln_lalu')); ?><br>

<br>
<br>
Posisi Aktual<br>
NoA : <?php echo e($record->sum('noa')); ?><br>
NoC : <?php echo e($record->sum('noc')); ?><br>
Target EoM : <?php echo e($record->sum('target_eom_noc')); ?><br>
% EoM : <?php echo e($record->sum('noc') / $record->sum('target_eom_noc') * 100); ?><br>
Growth : <?php echo e($record->sum('noc') - $record->sum('noc_bln_lalu')); ?><br>
DO Bulan Ini : <?php echo e($record->sum('do_bln_ini')); ?><br>
Target EoY : <?php echo e($record->sum('target_eoy_noc')); ?><br>
% EoY : <?php echo e($record->sum('noc') / $record->sum('target_eoy_noc') * 100); ?><br>
<hr>
OS : <?php echo e($record->sum('os_actual')); ?><br>
Target EoM : <?php echo e($record->sum('target_eom_os')); ?><br>
% EoM : <?php echo e($record->sum('os_actual') / $record->sum('target_eom_os') * 100); ?><br>
Growth : <?php echo e($record->sum('os_actual') - $record->sum('os_bln_lalu')); ?><br>
Run Off (1 Minggu) : <?php echo e($record->sum('runoff')); ?><br>
Run Off (1 Bulan) : <?php echo e($record->sum('runoff') * 4); ?><br>
Target EoY : <?php echo e($record->sum('target_eoy_os')); ?><br>
% EoY : <?php echo e($record->sum('os_actual') / $record->sum('target_eoy_os') * 100); ?><br>
<hr>
DRTD (NoA) : <?php echo e($record->sum('kewajiban_drtd_noa')); ?><br>
DRTD (Rp) : <?php echo e($record->sum('kewajiban_drtd_nominal')); ?><br>
UK & PNC AO (Harian) : <?php echo e($record->sum('uk_dan_pnc_ao')); ?><br>


<br>
<br>
Quality Aktual<br>
NoA PAR : <?php echo e($record->sum('noa_par')); ?><br>
Progress : <?php echo e($record->sum('noa_par') - $record->sum('noa_par_bln_lalu')); ?><br>
% NoA PAR : <?php echo e($record->sum('noa_par') / $record->sum('noa') * 100); ?><br>
<hr>
OS PAR : <?php echo e($record->sum('os_par')); ?><br>
Progress : <?php echo e($record->sum('os_par') - $record->sum('os_par_bln_lalu')); ?><br>
% OS PAR : <?php echo e($record->sum('os_par') / $record->sum('os_actual') * 100); ?><br>
% RR : <?php echo e($record->sum('percentage_rr')); ?><br>
Target EoM : <?php echo e($record->sum('target_eom_par')); ?><br>
% EoM : <?php echo e($record->sum('target_eom_par') / $record->sum('os_par')  * 100); ?><br>
<hr>
NoA NPL : <?php echo e($record->sum('noa_npl')); ?><br>
Progress : <?php echo e($record->sum('noa_npl') - $record->sum('noa_npl_bln_lalu')); ?><br>
% NoA NPL : <?php echo e($record->sum('noa_npl') / $record->sum('noa') * 100); ?><br>
<hr>
OS NPL : <?php echo e($record->sum('os_npl')); ?><br>
Progress : <?php echo e($record->sum('os_npl') - $record->sum('os_npl_bln_lalu')); ?><br>
% OS NPL : <?php echo e($record->sum('os_npl') / $record->sum('os_actual') * 100); ?><br>
Target EoM : <?php echo e($record->sum('target_eom_npl')); ?><br>
% EoM : <?php echo e($record->sum('target_eom_npl') / $record->sum('os_npl')  * 100); ?><br>
<hr>
PKM : <?php echo e($record->sum('pkm')); ?><br>
Anggota > 30 : <?php echo e($record->sum('pkm_gt_30')); ?><br>
Anggota < 10 : <?php echo e($record->sum('pkm_lt_10')); ?><br>

<br>
<br>
SDM
AO : <?php echo e($record->sum('jumlah_ao')); ?><br>
FAO : <?php echo e($record->sum('fao')); ?><br>
SAO : <?php echo e($record->sum('sao')); ?><br>
KUM : <?php echo e($record->sum('kum')); ?><br>
Keb. AO : <?php echo e($record->sum('kebutuhan_ao')); ?><br>
Keb. FAO : <?php echo e($record->sum('kebutuhan_fao')); ?><br>
Keb. SAO : <?php echo e($record->sum('kebutuhan_sao')); ?><br>
Keb. KUM : <?php echo e($record->sum('kebutuhan_kum')); ?><br>

<?php /**PATH D:\Kerja\pnm-mekaar\resources\views/welcome.blade.php ENDPATH**/ ?>